//Jacob Holcomb
//Program 5

import java.util.Random;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class TicTacToeGame {
	
	public static void main(String [] args)
	{
		GameBoard Game = new GameBoard();
		Scanner sc = new Scanner(System.in);
		Game.showBoard();
				
		while (Game.checkWin() == 'P')			
		{
			if (Game.validPlayCount() % 2 == 0) //if it is the players
			{
				boolean haveInput = false;
				int row, col;
				
				do
				{
					row = Integer.parseInt(JOptionPane.showInputDialog("What row? > "));
					col = Integer.parseInt(JOptionPane.showInputDialog("What column? > "));
					if (!(row > 0 && col > 0 && row < 4 && col < 4))
					{
						JOptionPane.showMessageDialog(null, "Invalid location\nPlease select a row and column between 1 and 3");
					}
					else
						haveInput = true;
				}while(!haveInput);
				
				System.out.println();
				boolean valid = Game.play(true, row-1, col-1);
				while (! valid)
				{
					Game.showBoard();
					JOptionPane.showMessageDialog(null, "That position is already occupided.");
					row = Integer.parseInt(JOptionPane.showInputDialog("What row? > "));
					col = Integer.parseInt(JOptionPane.showInputDialog("What column? > "));
					System.out.println();
					valid = Game.play(true, row, col);
				}//while
				Game.showBoard();
				
				if (Game.checkWin() == 'T')
					JOptionPane.showMessageDialog(null, "Tie");
				else if (Game.checkWin() != 'P') 
					JOptionPane.showMessageDialog(null, Game.checkWin() + "s win");
				
			}// if
			else
			{
			//Computer turn
			Random rand = new Random();
			int r = rand.nextInt(3);
			int c = rand.nextInt(3);
			boolean valid = Game.play(false, r, c);
			while (! valid)
			{
				r = rand.nextInt(3);
				c = rand.nextInt(3);
				valid = Game.play(false, r, c);				
			}//while
			//System.out.println("Computer plays: " + r + " " + c);
			r++;
			c++;
			JOptionPane.showMessageDialog(null, "Computer plays: " + r + ", " + c);
			Game.validPlayCount();
			Game.showBoard();
			
			if (Game.checkWin() == 'T')
				JOptionPane.showMessageDialog(null, "Tie");
			else if (Game.checkWin() != 'P')
				JOptionPane.showMessageDialog(null, Game.checkWin() + "s win");
			
			}//else
		}//while		
	}//main
}//class

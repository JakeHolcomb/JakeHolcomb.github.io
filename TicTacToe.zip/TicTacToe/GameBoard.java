//Jacob Holcomb
//Program 5

public class GameBoard {

	private char board[][] = new char[3][3];
	private int plays;
	
	public GameBoard()
	{
		plays = 0;
		for (int row = 0; row < board.length; row++)
			for (int col = 0; col < board[row].length; col++)
				board[row][col] = ' ';
	}//GameBoard
	
	public boolean play(boolean x, int row, int column)
	{
		char c;
		if (x == true)
			c = 'X';
		else
			c = 'O';
		if (board[row][column] == ' ')
		{	
			board[row][column] = c;
			plays++;
			return true;
		}//if
		else
		{
			return false;
		}//else
	}//play
	
	public int validPlayCount()
	{
		return plays;
	}//validPlayCount
	
	public char checkWin()
	{
		//Check rows for 3 in a row.
		for (int row = 0; row < board.length; row++)
		{
			char pos0 = board[row][0];
			
			if (pos0 != ' ')//do not want to check for 3 ' ' in a row
			{
				char pos1 = board[row][1];
				char pos2 = board[row][2];
			
				if (pos0 == pos1 && pos0 == pos2)
					return pos0;
			}//if
		}//for
		
		//Check columns for 3 in a row
		for (int col = 0; col < board.length; col++)
		{
			char pos0 = board[0][col];
			
			if (pos0 != ' ')//Don't want to check for 3 ' ' in a row
			{
				char pos1 = board[1][col];
				char pos2 = board[2][col];
				
				if (pos0 == pos1 && pos0 == pos2)
					return pos0;				 
			}//if
		
		}//for
		
		//Check first diagonal
		if (board[0][0] != ' ')//Avoid 3 spaces being counted as a win
		{
			if (board[0][0] == board[1][1] && board[0][0] == board[2][2])
				return board[0][0];
		}//if
		//Check second diagonal
		if (board[0][2] != ' ')//Avoid 3 spaces being counted as a win 
		{
			if (board[0][2] == board[1][1] && board[0][2] == board[2][0])
				return board[0][2];
		}//if
		
		//if every section on the board has been played in and still none of the
		//win conditions are true then it must be a tie
		if (plays >= 9)
			return 'T';
		
		//if the game has not been won yet and it is not a tie then it must still be going
		return 'P';
	}//checkWin
	
	public void showBoard()
	{
		System.out.println(" " + board[0][0] + "  | " + board[0][1] + " | " + board[0][2]);
		System.out.println(" ---+---+---");
		System.out.println(" " + board[1][0] + "  | " + board[1][1] + " | " + board[1][2]);
		System.out.println(" ---+---+---");
		System.out.println(" " + board[2][0] + "  | " + board[2][1] + " | " + board[2][2]);
	}//showBoard
}//class
